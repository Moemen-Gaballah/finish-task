<?php
return [
    'welcome' => 'مرحبا بيك',
];