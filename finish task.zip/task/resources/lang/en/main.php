<?php
return [
    'welcome' => 'Welcome',
];