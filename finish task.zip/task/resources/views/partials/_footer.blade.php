<div class="footer">
    <p>Copyright &copy; <a href="https://www.facebook.com/MoemenGaballah"> Moemen Gaballah </a> 2018 </p>
</div>

<!-- Scripts -->
<script src="{{ asset('js/app.js') }}"></script>
@yield('script')
</body>
</html>