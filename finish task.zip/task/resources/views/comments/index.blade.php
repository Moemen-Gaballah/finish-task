@extends('main')
@section('title', 'Comment')
@section('content')
    <div class="container">
        <div class="row">
            <h2 style="margin-top: 6px; width: 50%; float:left;">Show Comment</h2>
            <table class="table table-striped">
                <thead>
                <tr>
                    <th>#</th>
                    <th>User_Name</th>
                    <th>Body</th>
                    <th>Status</th>
                    <th>Created_at</th>
                    <th>Control</th>
                </tr>
                </thead>
                <tbody>
                {{--@if(isset($comments))--}}
                    @foreach($comments as $comment)
                        <tr>
                            <td>{{$comment->id}}</td>
                            <td>{{$comment->user->name }}</td>
                            <td>{{$comment->body }}</td>
                            <td>{{$comment->status}}</td>
                            <td>{{$comment->created_at}}</td>
                            <td>
                                {{--<a href="{{ route('comment.edit', $comment->id) }}" class="btn btn-sm btn-primary">--}}
                                    {{--Edit--}}
                                {{--</a>--}}
                                {{ Form::open(['route' => ['comment.destroy', $comment->id], 'method' => 'DELETE']) }}
                                {{ Form::submit('Delete', ['class' => 'btn btn-sm btn-danger']) }}
                                {{ Form::close() }}
                                {{--<a href="{{ route('category.destroy', $cat->id) }}" class="btn btn-xs btn-danger"> Delete</a>--}}
                            </td>
                    @endforeach
                {{--@endif--}}
                </tbody>
            </table>
        </div>
    </div>
@endsection