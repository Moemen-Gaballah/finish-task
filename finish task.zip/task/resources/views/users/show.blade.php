@extends('main')
@section('title', 'Show User')
@section('content')
    <div class="container">
        <div class="row">

            <div class="col-md-8 col-md-push-2">
                @if($user->image !== null)
                    <img src="{{ asset('img/avatar'.$user->image) }}" style="width: 750px; height: 300px;">

                @else
                    <img src="{{ asset('img/avatar/avatar.jpg') }}" alt="Image Photo" style=" width: 750px; height: 300px; ">
                @endif
                <h2>Name: {{ $user->name }}</h2>
                <p>Email: {{ $user->email }}</p>
                <p>Role: {{ $user->role }}</p>
                <p>Gender: {{ $user->gender }}</p>
                <hr>
            </div>
        </div>
    </div>
@endsection