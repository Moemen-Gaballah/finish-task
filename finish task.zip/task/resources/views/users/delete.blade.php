@extends('main')
@section('title', 'Delete Account')
@section('content')
    <div class="container">
        <div class="row">

            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Delete Account</div>

                    <div class="panel-body">
                            <form class="form-horizontal" method="POST" action="{{ route('user.destroy', $user->id) }}">
                                <input type="hidden" name="_method" value="DELETE">
                                {{ csrf_field() }}
                                <label for="reason" class="float-left control-label">Why do you want delete Your account ?</label>
                                <textarea name="reason" rows="12" cols="75"></textarea>

                                <br>
                            <input type="submit" value="Delete Account" class="btn btn-danger">
                        </form>

                    </div>
                </div>
            </div>

        </div>
    </div>
@endsection