@extends('main')
@section('title', 'User')

@section('content')
    <div class="container">
        <div class="row">
            <h2 style="margin-top: 6px; width: 50%; float:left;">Show Users</h2>
            <a href="{{ url('/user/create') }}" style="float:right;" class="btn btn-primary pull-right">Create New User</a>

            <table class="table table-striped">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Gender</th>
                    <th>image</th>
                    <th>hobbies</th>
                    <th>role</th>
                    <th>verified</th>
                    <th>Control</th>
                </tr>
                </thead>
                <tbody>
                @foreach($users as $user)
                    <tr>
                        <td>{{$user->id}}</td>
                        <td>{{$user->name}}</td>
                        <td>{{$user->email }}</td>
                        <td>
                            @if ($user->image !== null)
                                <img src="{{asset('img/avater/'.$user->image)}}" style="width: 80px; height: 80px;">
                            @else
                                No Image!
                            @endif
                        </td>
                        <td>{{$user->gender}}</td>
                        <td>
                            {{--{{gettype($user->hobbies)}}--}}
                            @if(is_array($user->hobbies))
                                {{Implode (' - ', $user->hobbies)}}
                            @else
                                @php $hobbies = str_replace('["', '', $user->hobbies);
                                $hobbies = str_replace('","', ' - ', $hobbies);

                                @endphp
                                {{ str_replace('"]', '', $hobbies) }}
                                {{--{{$user->hobbies}}--}}
                            @endif

                        </td>
                        <td>{{$user->role}}</td>
                        <td>@if($user->verified == 1) verified @else Not Verified @endif</td>
                        <td>
                            <a href="{{ route('user.show', $user->id) }}" class="btn btn-sm btn-success">
                                Show
                            </a>
                            <a href="{{ route('user.edit', $user->id) }}" class="btn btn-sm btn-primary">
                                Edit
                            </a>
                            {{ Form::open(['route' => ['fast.delete.account', $user->id], 'method' => 'DELETE']) }}
                            {{ Form::submit('Delete', ['class' => 'btn btn-sm btn-danger']) }}
                            {{ Form::close() }}
                            {{--<a href="{{ route('category.destroy', $cat->id) }}" class="btn btn-xs btn-danger"> Delete</a>--}}
                        </td>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection