@extends('main')
@section('title', 'Edit User')
@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-push-2">
                <h1 class="text-center">Edit User</h1>
                {!! Form::model($user, ['route' => ['user.update', $user->id], 'method' => 'PATCH', 'files' => true]) !!}
                <div class="form-group">
                    {{ Form::label('name', 'Name', ['class' => 'col-md-4 control-label']) }}
                    <div class="col-md-6">
                        {{ Form::text('name', null, ['class' => 'form-control']) }}
                    </div>
                </div>

                <div class="form-group">
                    {{ Form::label('email', 'Email', ['class' => 'col-md-4 control-label']) }}
                    <div class="col-md-6">
                    {{ Form::text('email', null, ['class' => 'form-control']) }}
                    </div>
                </div>

                <div class="form-group">
                    {{ Form::label('image', 'Image', ['class' => 'col-md-4 control-label']) }}
                    <div class="col-md-6">
                        {{ Form::file('image', ['class' => 'form-control']) }}
                    </div>
                        @if($user->image !== null)
                        <img src="{{asset('img/avater/'.$user->image)}}" style="width: 150px; height: 100px;">
                    @endif
                </div>

                <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                    <label for="password" class="col-md-4 control-label">Password</label>

                    <div class="col-md-6">
                        <input id="password" type="password" class="form-control" name="password">

                        @if ($errors->has('password'))
                            <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                        @endif
                    </div>
                </div>

                <div class="form-group">
                    <label for="password-confirm" class="col-md-4 control-label">Confirm Password</label>

                    <div class="col-md-6">
                        <input id="password-confirm" type="password" class="form-control" name="password_confirmation">
                    </div>
                </div>
                @if(auth()->user()->role == 'Admin')
                <div class="form-group">
                    {{ Form::label('verified', 'Verified', ['class' => 'col-md-4 control-label']) }}
                    <div class="col-md-6">
                        {{ Form::select('verified',['0' => 'Disactive', '1' => 'Active'], null,['class' => 'form-control','placeholder' => 'Choose Verified...'] ) }}
                    </div>
                </div>

                <div class="form-group">
                    {{ Form::label('role', 'Role', ['class' => 'col-md-4 control-label']) }}
                    <div class="col-md-6">
                        {{ Form::select('role',['User' => 'User', 'Admin' => 'Admin'], null,['class' => 'form-control','placeholder' => 'Choose Role...'] ) }}
                    </div>
                </div>
                @endif
                <div class="form-group">
                    <label for="gender" class="col-md-4 control-label">Gender</label>
                    <div class="col-md-6">
                        <input type="radio" name="gender" value="male" required @if($user->gender == 'male') checked @endif > Male
                        <input type="radio" name="gender" value="female" required @if($user->gender == 'female') checked @endif > Female
                        <input type="radio" name="gender" value="other" required @if($user->gender == 'other') checked @endif > Other
                    </div>
                </div>

                <div class="form-group">
                    <label for="hobbies" class="col-md-4 control-label">Hobbies</label>

                    <div class="col-md-6">
                        <input type="checkbox" name="hobbies[]" value="Running" @if(in_array("Running", json_decode($user->hobbies, true))) checked @endif > Running
                        <input type="checkbox" name="hobbies[]" value="Walking" @if(in_array("Walking", json_decode($user->hobbies, true))) checked @endif > Walking
                        <input type="checkbox" name="hobbies[]" value="Swimming" @if(in_array("Swimming", json_decode($user->hobbies, true))) checked @endif > Swimming
                        {{----}}
                        {{--<input type="checkbox" name="hobbies[]" value="Running" @if(in_array("Running", $user->hobbies)) checked @endif > Running--}}
                        {{--<input type="checkbox" name="hobbies[]" value="Walking" @if(in_array("Walking", $user->hobbies)) checked @endif > Walking--}}
                        {{--<input type="checkbox" name="hobbies[]" value="Swimming" @if(in_array("Swimming", $user->hobbies)) checked @endif > Swimming--}}

                    </div>
                </div>

                <div class="form-group">
                    <div class="col-md-6 col-md-offset-4">
                        {{ Form::submit('Edit User', ['class' => 'btn btn-primary']) }}
                        {!! Form::close() !!}
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-md-6 col-md-offset-4">
                        <h3>If you want delete Your Account</h3>
                        <a href="/user/{{$user->id}}/delete">Delete Account</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection