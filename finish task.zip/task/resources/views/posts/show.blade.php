@extends('main')
@section('title', 'Show Post')
@section('content')
    <div class="container">
        <div class="row">

            <div class="col-md-8 col-md-push-2">
                @if($post->image !== null)
                    <img src="{{ asset('img/'.$post->image) }}" style="width: 750px; height: 300px;">

                @else
                    <img src="{{ asset('img/default.png') }}" alt="Image Photo" style=" width: 750px; height: 300px; ">
                @endif
                <h2>{{ $post->title }}</h2>
                <p>{{ $post->body }}</p>
                <hr>
                <div class="show-comment">
                    <div class="row">
                        <div class="col-md-6 text-center">
                            <h3>Comment</h3>
                            @foreach($comments as $comment)
                                <ul>
                                    <li>{{ $comment->user->name }}</li>
                                    <li>{{ $comment->body }}</li>
                                    <li>{{ $comment->created_at }}</li>
                                </ul>
                                <hr>
                            @endforeach
                        </div>
                    </div>
                </div>

                @if(!Auth::check())
                        <h1 class="text-center">You must be login to add comment <a href="/login"> Login </a></h1>
                @else
                <div class="comment">
                    <div class="row">
                        <div class="col-md-10 text-center">
                            <h1 class="text-center">Create New Comment</h1>
                            {!! Form::open(['route' => 'comment.store', 'method' => 'POST']) !!}

                            <input name="post_id" type="hidden" value="{{ $post->id }}">
                            <div class="form-group col-md-12">
                                {{ Form::label('body', 'Comment') }}
                                {{ Form::textarea('body', null, ['class' => 'form-control', 'placeholder' => 'Comment ...']) }}
                            </div>

                            {{ Form::submit('Create Comment', ['class' => 'btn btn-primary']) }}
                            {!! Form::close() !!}
                        </div>
                    </div>
                </div>
                @endif
            </div>
        </div>
    </div>
@endsection