@extends('main')
@section('title', 'deleted Reason')

@section('content')
<div class="container">
    <div class="row">
        <h2 style="margin-top: 6px; width: 50%; float:left;">Reasons Deleted</h2>

        <table class="table table-striped">
            <thead>
            <tr>
                <th>#</th>
                <th>email</th>
                <th>reason</th>
            </tr>
            </thead>
            <tbody>
                @foreach($reasons as $reason)
                <tr>
                    <td>{{ $reason->id }}</td>
                    <td>{{ $reason->name}}</td>
                    <td>{{ $reason->email }}</td>
                    <td>
            {{--<!--                    <a href="{{ route('user.show', $reason->id) }}" class="btn btn-sm btn-success">-->--}}
            {{--<!--                        Show-->--}}
            {{--<!--                    </a>-->--}}
            {{--<!--                    <a href="{{ route('user.edit', $reason->id) }}" class="btn btn-sm btn-primary">-->--}}
            {{--<!--                        Edit-->--}}
            {{--<!--                    </a>-->--}}
                        {{ Form::open(['route' => ['reason.destroy', $reason->id], 'method' => 'DELETE']) }}
                        {{ Form::submit('Delete', ['class' => 'btn btn-sm btn-danger']) }}
                        {{ Form::close() }}
            {{--<!--                    <a href="{{ route('category.destroy', $cat->id) }}" class="btn btn-xs btn-danger"> Delete</a>-->--}}
                    </td>
                @endforeach
</tbody>
</table>
</div>
</div>
@endsection