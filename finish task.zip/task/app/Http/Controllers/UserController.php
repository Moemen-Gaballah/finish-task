<?php

namespace App\Http\Controllers;

use App\Reason;
use App\User;
use File;
use Session;
use Auth;
use Illuminate\Http\Request;

class UserController extends Controller
{
    public function __construct() {
        $this->middleware('admin', ['only' => ['index', 'create',]]);
        $this->middleware('auth', ['except' => ['index']]);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $users = User::all();

        return view('users.index', compact('users'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('users.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
//          dd($request->all());
        // Save a New User And Then Redirect Back To USER
        $this->validate($request, array(
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|unique:users|max:255',
            'password' => 'required|string|min:6|confirmed',
            'gender' => 'required|string',
            'verified' => 'required',
            'role' => 'required',
            'hobbies' => 'required',
//            'image' => 'sometimes|image|mimes:jpeg,png,jpg|max:2048',
        ));

        $user = new User();
        $user->name = $request->name;
        $user->email = $request->email;
        $user->password = bcrypt($request->password);
        $user->gender = $request->gender;
        $user->verified = $request->verified;
        $user->role = $request->role;
        $user->api_token= bin2hex(openssl_random_pseudo_bytes(30));
        $user->hobbies = json_encode($request->hobbies);

//        dd(json_encode($request->hobbies));
        // Save Our Image
        if ($request->hasfile('image')) {
            $image = $request->file('image');
            $filename = time().'.'.$image->getClientOriginalExtension();
            $location = public_path('/img/avater');
            $user->image = $filename;
            $image->move($location, $filename);
        }

        $user->save();

        // Set Flash data with success message
        Session::flash('success', 'New Category has been created.');
        return redirect('/user');


    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $user = User::findOrFail($id);

        return view('users.show', compact('user'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $user = User::findOrFail($id);
        if(auth()->user()->role === 'Admin' OR auth()->user()->id == $user->id){
            return view('users.edit', compact('user'));
        }else{
            return redirect('/')->with('error','You have not admin access Or Your Profile');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
//        dd($request->all());
        $user = User::find($id);
        if($request->email == $user->email){
            $this->validate($request, array(
                'name' => 'required|string|max:255',
                'gender' => 'required|string',
                'hobbies' => 'required',
                'image' => 'sometimes|image|mimes:jpeg,png,jpg|max:2048',
            ));
        }else {
            $this->validate($request, array(
                'name' => 'required|string|max:255',
                'email' => 'required|string|email|unique:users|max:255',
                'gender' => 'required|string',
                'hobbies' => 'required',
                'image' => 'sometimes|image|mimes:jpeg,png,jpg|max:2048',
            ));
        }
        if (!empty($request->password)){
            $this->validate($request, array(
                'password' => 'required|string|min:6|confirmed',
            ));
        }

        // Save the data to the database
        $user->name = $request->name;
        $user->email = $request->email;
        $user->password = bcrypt($request->password);
        $user->gender = $request->gender;
        $user->verified = $user->verified;
        $user->role = $user->role;
        $user->hobbies = json_encode($request->hobbies);
        $user->api_token = $user->api_token;


        if ($request->hasFile('image')) {
            // Add the new Photo
            $image = $request->file('image');
            $filename = time() . '.' . $image->getClientOriginalExtension();
            $location = public_path('/img/avater');

            $image->move($location, $filename);

            // Delete Old Photo
            $oldPhotoName = $user->image;

            // Update The database
            $user->image = $filename;

            //Delete the old Photo
            File::delete('img/avater/'.$oldPhotoName);
        }
        $user->save();

        // Set Flash data with success message
        Session::flash('success', 'This post was successfully saved.');
        return redirect('/');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
//        dd($request->all());
        $this->validate($request, array(
            'reason' => 'required|string',
        ));

        // Store in the database
        $reason = new Reason;

        $reason->email = Auth::user()->email;
        $reason->reason = $request->reason;
        $reason->save();

        $user = User::find($id);
        $user->delete();

        Session::flash('success', 'The User Was successfully deleted.');
        return redirect('/');
    }

    public function delete($id)
    {
        $user = User::findOrFail($id);
        if(auth()->user()->role === 'Admin' OR auth()->user()->id == $user->id) {
            $user = User::find($id);
            return view('users.delete', compact('user'));
        }else{
            return redirect('/')->with('error','You have not admin access Or Your Profile');
        }
    }

    public function fastdelete($id)
    {
        $user = User::find($id);
        $user->delete();

        Session::flash('success', 'The User Was successfully deleted.');
        return redirect('/user');
    }

    // Api To User
//    public function api(){
////        return json_encode(['message' => 'Welcome To Api Users']);
//        return response()->json(['message' => 'Welcome To Api Users']); // More Security
//    }

}
