<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\UserResource;
use App\User;
use Illuminate\Http\Response;
use Validator;
use Illuminate\Http\Request;

class UsersController extends Controller
{
    use ApiResponseTrait;

    public function index()
    {
        $users = User::paginate($this->paginateNumber);
        return $this->apiResponse($users);
    }

    public function show($id)
    {
        $user = User::find($id);
        if($user){
            return $this->returnSuccessUser($user);
        }
        return $this->notFoundResponse();
    }

    public function delete($id)
    {
        $user = User::find($id);
        if($user) {
            $user->delete();
            return $this->deleteResponse($user);
        }
        return $this->notFoundResponse();
    }

    public function store(Request $request){
        // Validation
        $validation = $this->validation($request);

        if($validation instanceof Response){
            return $validation;
        }

//       $user = User::create($request->all());
         $user = User::create([
             'name' => $request->name,
            'email' => $request->email,
            'password' => bcrypt($request->password),
            'gender' => $request->gender,
            'hobbies' => json_encode($request->hobbies),
             'api_token' => bin2hex(openssl_random_pseudo_bytes(30)),
         ]);
        if($user){
            return $this->createdResponse(new UserResource($user));
        }
        return $this->apiResponse('null','Un Know error', 520);
    }

    public function update(Request $request, $id)
    {
        $validation = $this->validation($request);

        if($validation instanceof Response){
            return $validation;
        }

        $user = User::find($id);

        if(!$user){
            return $this->notFoundResponse();
        }

//        $user->update($request->all());
        $user->update([
            'name' => $request->name,
            'email' => $request->email,
            'password' => bcrypt($request->password),
            'gender' => $request->gender,
            'hobbies' => json_encode($request->hobbies),
            'api_token' => $user->api_token,
        ]);
        if($user){
            return $this->returnSuccessUser($user);
        }
        $this->unKnowError();
    }

    public function validation($request)
    {
        return $this->apiValidation($request, array(
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|unique:users|max:255',
            'password' => 'required|string|min:6',
            'gender' => 'required|string',
            'hobbies' => 'required',
            'image' => 'sometimes|image|mimes:jpeg,png,jpg|max:2048',
        ));
    }

    public function returnSuccessUser($user){
        return $this->apiResponse($user);
    }

}
