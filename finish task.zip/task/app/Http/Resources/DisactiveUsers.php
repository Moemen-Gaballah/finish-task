<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\ResourceCollection;

class DisactiveUsers extends ResourceCollection
{
    /**
     * Transform the resource collection into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
//        return parent::toArray($request);
        return [
            'name' => $request->name,
            'email' => $request->email,
            'profile' => url('user/'. $request->id .'/'),
            'posts' => $request->posts,
        ];
    }

    public function with($request)
    {
        return [
            'version' => '2.0.0',
            'attribution' => url('/terms-of-service'),
            'valid_as_of' => date('D, d M Y H:i:s'),
        ];
    }
}
