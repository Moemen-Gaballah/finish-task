<?php

namespace App\Http\Middleware;

use Closure;
use App;

class Lang
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if(auth()->user())
        {
            if(empty(auth()->user()->lang))
            {
                App::setLocale('en');
            }else{
                $lang = auth()->user()->lang;
                App::setLocale($lang);
            }
        }else{
            if(session()->has('lang')){
                $lang = session()->get('lang');
                App::setLocale($lang);
            }else {
                App::setLocale('en');
            }
        }
        return $next($request);
    }
}
